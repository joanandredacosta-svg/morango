#ifndef MINITALK_H
# define MINITALK_H

# include <signal.h>
# include <unistd.h>
# include <stdlib.h>
# include <stdio.h>

void	envia_char(int pid, unsigned char c);

void	recebe_bit(int sig);

#endif
